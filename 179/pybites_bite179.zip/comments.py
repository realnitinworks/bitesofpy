def strip_comments(code):
    # see Bite description
    pass